select * from imovel;
select * from casa;
select * from apartamento;
select * from locador;

insert into casa values (
	1,
	'Casa com 3 quartos, 2 banheiros , uma suite, area de serviço
	area de lazer',
	TRUE
);

insert into apartamento values (
	4,
	'Casa com 5 quartos, 4 banheiros ,3 suite,cozinha gigante,
	varanda,area de serviço 50m², 2 andares, de frente para o mar
	O APARTAMENTO PERFEITO PARA VOCÊ!!!',
	TRUE
);